---
name: decisioncraft
description: Point it at anything (a codebase, a folder of notes, a page or a topic) and get a map of how it works today, how it could work, the gaps as user stories with 'done when' checks, and a note from every role. It also helps someone weigh a choice at the right depth, from a quick side-by-side in the chat to a full team review. Use for 'map this codebase', 'show me how X works', 'as-is and to-be', 'where are the gaps', 'turn these notes into a process map', 'review this process', and whenever someone is weighing options without saying decision, such as 'should I', 'torn between', 'pros and cons', 'which is better', 'renew or buy', 'keep or replace', 'help me think this through', or comparing offers, quotes or vendors. Not for factual questions or trivial picks.
---
# Decisioncraft (skill mode)

You are the model. Decisioncraft is a plain Python library bundled in `scripts/` that checks and
draws what you write. It needs no API key, no pip install and no network. Run it from this
skill's folder:

```sh
python3 scripts/dc.py <command> [options] --json
```

Every command prints one JSON result (`ok`, `result`, `error`). Never call `draft`,
`perspectives` or a plain `map` (they need an API key): you do that thinking yourself.

## Pick the depth first

```sh
python3 scripts/dc.py triage --text "<what the person said>" --json
```

It returns a mode and an `offer` sentence. Offer, don't take over.

- **none**: just answer in a sentence or two. Build nothing.
- **quick**: a small scored table in the chat, no files:
  `python3 scripts/dc.py quick --option "Keep" --option "Buy used" --criterion "Cost" --criterion "Safety" --score "Keep=Cost=4" ... --json`
  Show the returned Markdown table, the lean and the one thing to check first.
- **guided**: ask one question at a time with the interview, then build a canvas:
  `python3 scripts/dc.py interview --dir work --text "<first message>" --next --json`, then
  `python3 scripts/dc.py interview --dir work --answer "<their reply>" --next --json` until it
  says done. Ask each question in your own words; "not sure" is a fine answer.
- **team**: the same as guided, then the full canvas with every role's notes.

## Map something (as-is, to-be, gaps, notes)

When someone uploads files or a folder and asks how it works or what is missing:

1. `python3 scripts/dc.py map <uploaded folder or file> --starter --dir map --json` writes
   `map/material/digest.md` (numbered lines), a starter `map/model.json` and `map/FILL-IN.md`.
2. Read `references/model-format.md` and `references/writing-guide.md`, then fill in
   `map/model.json` from the digest: how it works today (each step with evidence quoted exactly,
   with its file and line), the planned way, the gaps as user stories with "done when" checks,
   and a short note from each role that ends in a question.
3. `python3 scripts/dc.py validate map/model.json --json`. Fix every error it lists. The
   untouched starter fails on purpose ("The map is empty"): never hand over an empty canvas.
4. `python3 scripts/dc.py render map/model.json --out map/canvas.html --json`.
5. Give the person `map/canvas.html` as a downloadable file. It opens offline in any browser.
   Summarise in a few plain sentences what it shows and the most urgent questions
   (`python3 scripts/dc.py questions map/model.json --json`).

For a topic with no files, write the model from what the person tells you and mark claims you
could not check.

## Other useful commands

- `guide`: the model format and writing guide (same as `references/`).
- `example car --out car --json` (or business, technical, engineering, medical, map): a finished
  example to show what a map looks like; render it with `render car/model.json`.
- `words model.json`: the whole model as readable text.
- `merge model.json review1.json review2.json`: where reviewers agree and split.
- `diff old.json new.json`: what changed between versions.

## Writing

Plain words, short sentences, no jargon. Every note from a role ends in a question. Never invent
evidence: quote the material exactly or say it is unchecked.

## Not for

Factual questions, trivial picks, or code-level choices inside a coding task ("map or list?"),
unless the person asks to lay options out or review a process.

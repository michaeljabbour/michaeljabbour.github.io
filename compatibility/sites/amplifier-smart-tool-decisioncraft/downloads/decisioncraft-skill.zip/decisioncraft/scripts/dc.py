#!/usr/bin/env python3
"""Run the bundled Decisioncraft library: python3 scripts/dc.py <command> [options]."""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault("DECISIONCRAFT_HOST", "skill")

from decisioncraft.cli import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main())
